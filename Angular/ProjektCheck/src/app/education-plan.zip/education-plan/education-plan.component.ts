import { Component, OnInit } from '@angular/core';
import {DataService} from '../data.service';

@Component({
  selector: 'app-education-plan',
  templateUrl: './education-plan.component.html',
  styleUrls: ['./education-plan.component.css']
})
export class EducationPlanComponent implements OnInit {
  getDaten: String[];
  getEducation = [];

  constructor(private dataService: DataService) { }


   scrollWin(x,y){
      window.scrollBy(x,y);

    }

  isEducation(number){
  for(var i=0;i < 15;i++){
    if(number==this.getEducation[i].competenceId ){

      return true;
    }
  }
  return false;
  }

  isOK(checked){
    if(checked==true){
      return true;
    }
    else{
      return false;
    }

  }
  isNOK(checked){
    if(checked==false){
      return true;
    }
    else{
      return false;
    }

  }



  ngOnInit() {
  }

}
